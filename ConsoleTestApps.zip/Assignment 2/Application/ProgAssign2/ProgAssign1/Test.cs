﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ProgAssign2
{
    abstract class Test
    {
        public abstract int calculateScore(ArrayList memo, ArrayList user);
    }
}
