﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.Data.SqlClient;

namespace ProgAssign3
{
    #region Student tracking
    class Student
    {
        public void instructions()
        {
            String border = "\n*<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>*\n";
            Clear();
            WriteLine(border + "Now, as a student, take the test set by the lecturer...\n enter only the "
                + "correct letter and click Enter to continue\n" + border);
            ReadLine();
        }
        public void takeTest()
        {
            try
            {
                string cs = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=B:\ProgAssign\ProgAssign1\AppData.mdf;Integrated Security=True";
                SqlConnection cn = new SqlConnection(cs);
                cn.Open();

                WriteLine("Enter your student number :");
                string STUDENT_NO = ReadLine();
                WriteLine("Enter your firstName :");
                string FIRSTNAME = ReadLine();
                WriteLine("Enter your lastName :");
                string LASTNAME = ReadLine();

                WriteLine("Read the following questions and enter the correct answer for each question :\n ");
                //this quesry will select all the questions from the appdata database
                 string query = " select QUESTION, P_ANSWER1, P_ANSWER2, P_ANSWER3 from TEST";
                 SqlCommand cmd = new SqlCommand(query, cn);
                 ReadLine();

                WriteLine("Now that you've read the questions please answer the questions starting by the first question's answer :\n");
                WriteLine("Enter the answer for the first question :");
                string ANSWER = ReadLine();
                WriteLine("Enter the answer for the second question :");
                string ANSWER2 = ReadLine();
                WriteLine("Enter the answer for the third question :");
                string ANSWER3 = ReadLine();

                 string query1 = " insert into table TEST values ("+STUDENT_NO+",'"+FIRSTNAME+"','"+LASTNAME+"','" + ANSWER + "','"+ANSWER2+"',"+ANSWER3+")";
                 SqlCommand cmm = new SqlCommand(query1, cn);
                 int result = cmm.ExecuteNonQuery();
                 WriteLine(result + "record/s inserted");
                cn.Close();
            }
            catch (Exception e)
            {
                Write(e);
            }
        }
      #endregion

}
}
