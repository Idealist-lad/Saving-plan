﻿using System;
using static System.Console;
using System.Data.SqlClient;

namespace ProgAssign3
{
    //inherits class Test
    class Paper
    {
        //default constructor
        public Paper()
        {
            Console.WriteLine("Enter the topic for the test :");
           string topic = ReadLine();
        }
        public void memo()
        {
            try
            {
                string cs = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=B:\ProgAssign\ProgAssign1\AppData.mdf;Integrated Security=True";
                SqlConnection cn = new SqlConnection(cs);
                cn.Open();
                //Select all data from the test table
                string query = "select * from TEST";
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                cn.Close();
            }

            catch (Exception e)
            {
                Write(e);
            }
        }
        public void marker()
        {
            int counter = 0;

            try
            {
                string cs = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=B:\ProgAssign\ProgAssign1\AppData.mdf;Integrated Security=True";
                SqlConnection cn = new SqlConnection(cs);
                cn.Open();
                //sql query for marking
                string query = "SELECT t.Q_CODE , t.ANSWER , s.STUDENT_NO, s.ANSWER, s.ANSWER2, s.aNSWER3 FROM STUDENT s INNER JOIN TEST t ON t.Q_CODE = s.STUDENT_NO   IF t.ANSWER = s.ANSWER WHERE t.Q_CODE = 'Q_01' COUNTER + 1 ELSE COUNTER +0, IF t.ANSWER = s.ANSWER2 WHERE t.Q_CODE = 'Q_02' COUNTER + 1 ELSE COUNTER +0, IF t.ANSWER = s.ANSWER3 WHERE t.Q_CODE = 'Q_03' COUNTER + 1 ELSE COUNTER +0; ";

                SqlCommand cmd = new SqlCommand(query, cn);
                cn.Close();
            }

            catch (Exception e)
            {
                Write(e);
            }
        }
    }
}