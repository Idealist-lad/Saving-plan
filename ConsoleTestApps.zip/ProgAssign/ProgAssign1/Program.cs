﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using Lecturer;
using System.Data.SqlClient;

namespace ProgAssign3
{
    class Program
    {

        static void Main(string[] args)
        {
            //Creating objects for all the classes
            //to call the methods they contain
            Class1 setTest = new Class1();
            Student takeIt = new Student();
            
            // this objrect of lecturer will call the method for the lecturer to set the test
            //Calling methods with the objects of the classes
            setTest.welcomeMessage();
            setTest.instruction1();
            
            Paper paper = new Paper();
            setTest.Test();

            
            takeIt.instructions();
            takeIt.takeTest();



            
            

        }
    }
}
