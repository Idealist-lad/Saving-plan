﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using static System.Console;

namespace Lecturer
{
    #region Lecturer threat
    public class Class1
    {
        public void Test()
        {
            try
            {
                string cs = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=B:\ProgAssign\ProgAssign1\AppData.mdf;Integrated Security=True";
                SqlConnection cn = new SqlConnection(cs);
                cn.Open();

                for (int i = 0; i < 3; ++i)
                {
                    WriteLine("Enter test code(it should be < 5 charactrs as in like Q_01 :");
                    string Q_CODE = ReadLine();
                    WriteLine("Enter the question fot the test :");
                    string QUESTION = ReadLine();
                    WriteLine("Enter the first possible answer for the question :");
                    string P_ANSWER1 = ReadLine();
                    WriteLine("Enter the second possible answer for the question :");
                    string P_ANSWER2 = ReadLine();
                    WriteLine("Enter the third possible answer for the question :");
                    string P_ANSWER3 = ReadLine();
                    WriteLine("Enter the correct answer for the question");
                    string ANSWER = ReadLine();


                    string query = " insert into table TEST values ("+Q_CODE+",'"+QUESTION+"','"+P_ANSWER1+"','"+P_ANSWER2+ "','"+P_ANSWER3+"',"+ANSWER+")";
                    SqlCommand cmd = new SqlCommand(query,cn);
                    int result = cmd.ExecuteNonQuery();
                    WriteLine(result + "record/s inserted into the table");
                    ReadLine();
                }
                cn.Close();
            }
            catch (Exception e)
            {
                Write(e);
            }
        }
        public void welcomeMessage()
        {
            String border = "\n+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+#+\n";
            WriteLine("Welcome to the Multiple Choice Test Application where you'll have"
                + "\n  an opportunity to be both the lecturer student.\n\tClick Enter key to continue..." + border + border);
            ReadLine();
        }
        public void instruction1()
        {
            String border = "\n**********************************************************************************\n";
            Clear();
            Console.WriteLine(border + "You are the lecturer, set a test composed of three questions.\nEach question will have"
                + " 3 options and a correct answer.\n\tClick Enter to continue..." + border);
            ReadLine();
        }
    }
}
#endregion
